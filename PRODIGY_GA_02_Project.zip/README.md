# PRODIGY_GA_02

## Image Generation using Pretrained Models

This project demonstrates AI image generation using Stable Diffusion and pretrained deep learning models.

## Technologies Used
- Python
- Stable Diffusion
- Diffusers Library
- PyTorch
- Google Colab

## Features
- Text-to-image generation
- AI-generated artwork
- Uses pretrained generative AI models

## Project Objective
Generate realistic images from text prompts using diffusion-based generative AI models.

## Author
SUMADHAR
